function calculatePriceSum(){
	var value = 0;
	for (var i in storage.products){
		var sPrice = parseFloat(storage.products[i].price);
		var number = parseInt(storage.products[i].quantity);
	
		value = value + sPrice * number;
		console.log(value);
	}
	el('total_price').innerHTML = "Price: $"+value;
}

window.onload = function updateCart(){
	//Read local storage
	storage = window.localStorage.getItem('cart_storage');
	storage = storage ? JSON.parse(storage):{"products":[]}; //storage is an object now
	//restore shopping list

	console.log(storage);
	
	// cartSection = []
	// for (var j = 0; j < storage.products.length; j++){
	// 	cartSection.push('<section id="cart_item_pid',parseInt(storage.products[j].pid),'"></section>');
	// }
	// el('cart').innerHTML = cartSection.join('');

	for (var i in storage.products){
		pid = storage.products[i].pid;
		var cartList = [];
		myLib.post({action:'prod_fetchProdDetail_1',pid:pid}, function(json){
			for(var j in storage.products){
				if(json[0].pid == storage.products[j].pid){
					var qty = storage.products[j].quantity;
				}
			}
			cartList.push('<section id="cart_item_pid',parseInt(json[0].pid),'"><p>',json[0].name.escapeHTML(),'</p> <input class="c_qty" type="number" value=',parseInt(qty),'><p id="cprice',parseInt(json[0].pid),'">@ $',parseFloat(json[0].price),'</p></section>');
			el('cart').innerHTML = cartList.join('');
		});
	}
	calculatePriceSum();
}

function ClearLocalStorage(){
	storage = {"products":[]};
	window.localStorage.setItem('cart_storage',JSON.stringify(storage));
	window.location.reload();
}

$(document).on('click', "#clear-cart", function(e){
	ClearLocalStorage();
});

function SaveToLocalStorage(storage){
	// console.log(storage);
	window.localStorage.setItem('cart_storage',JSON.stringify(storage));
}

$(".c_qty").bind('keyup mouseup', function () {
    alert("changed");            
});

$(document).on('click', "button.addBtn", function(e){
	var target = e.target;
	var price = target.previousElementSibling.innerHTML;
	var name = target.previousElementSibling.previousElementSibling.innerHTML;
	var pid = target.parentNode.id.replace(/^prod/, '');
	
	//console.log(price, name);
	var tmp = [];
	tmp.push(el('cart').innerHTML);
	var found = false;
	var found_storage = null;
	for (var i in storage.products){
		if (storage.products[i].pid == pid){
			found = true;
			found_storage = i;
			break;
		}
	}

	if(found == false){
		tmp.push('<section id="cart_item_pid',parseInt(pid),'"><p>',name,'</p> <input type="number" value=',1,'> <p>@ ',price,'</p></section>')
		// console.log(tmp);
		el('cart').innerHTML = tmp.join('');
		// storage.products.push();
		price = price.replace(/\$/, '');
		var new_item = {"pid":pid.toString(), "quantity":"1", "price":parseFloat(price)};
		storage.products.push(new_item);
		SaveToLocalStorage(storage);
	}else{
		var cpd = '#cart_item_pid'+pid+' input';
		var value = parseInt($(cpd).attr("value")) + 1;
		$(cpd).attr("value", value);
		console.log(found_storage);
		storage.products[found_storage].quantity = value.toString();
		SaveToLocalStorage(storage);
	}
	calculatePriceSum();
});













